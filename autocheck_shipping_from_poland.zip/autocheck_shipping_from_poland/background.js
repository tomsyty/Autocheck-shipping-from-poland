(function main() {
  console.log('Załadowano rozszerzenie');
  checkUpdate();
})();	

async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Autocheck-shipping-from-poland/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Autocheck-shipping-from-poland' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		} else {
			throw new Error(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Autocheck-shipping-from-poland' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				console.log(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('Brak pliku z informacją o aktualizacji');
	}
}