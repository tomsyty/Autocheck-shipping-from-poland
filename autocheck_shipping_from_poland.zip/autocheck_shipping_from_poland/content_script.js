console.log('Załadowano skrypt AutocheckShippingFromPoland'); 
const currentLocation = window.location.href;
const params = new URL(currentLocation).searchParams;
const sendFrom = params.get('miejsce-wysylki');
if (sendFrom === null) {
  if (params.size > 0) window.location.href = currentLocation + '&miejsce-wysylki=polska';
  else window.location.href = currentLocation + '?miejsce-wysylki=polska';
}